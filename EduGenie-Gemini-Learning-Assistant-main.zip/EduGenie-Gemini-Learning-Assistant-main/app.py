import os
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Optional: add your Gemini API key as an environment variable named GEMINI_API_KEY.
# The app still runs in demo mode without a key.
def ask_gemini(prompt):
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        return None
    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=(
                "You are EduGenie, a friendly study assistant. Explain clearly for students. "
                "Use simple language and steps when useful.\n\nStudent question: " + prompt
            ),
        )
        return response.text
    except Exception as exc:
        return "I couldn't connect to Gemini right now. Check your API key and internet connection. Details: " + str(exc)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}
    prompt = (data.get("question") or "").strip()
    if not prompt:
        return jsonify({"answer": "Please type a question first."}), 400

    answer = ask_gemini(prompt)
    if answer is None:
        answer = (
            "Demo mode is running successfully! Your question was: “" + prompt + "”\n\n"
            "To enable AI answers, add a Gemini API key as GEMINI_API_KEY and install the "
            "packages listed in requirements.txt. Until then, this demo confirms that the "
            "frontend and Python backend are connected."
        )
    return jsonify({"answer": answer})

if __name__ == "__main__":
    app.run(debug=True)

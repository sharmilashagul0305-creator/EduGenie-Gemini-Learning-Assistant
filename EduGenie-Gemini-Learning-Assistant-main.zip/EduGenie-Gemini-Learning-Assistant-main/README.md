# EduGenie – Gemini Learning Assistant

EduGenie is a student project with a simple HTML/CSS/JavaScript frontend and a Python Flask backend. It provides a chat-style study assistant interface.

## Project structure

```text
EduGenie_Gemini_Learning_Assistant/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── script.js
```

## Requirements

- Python 3.10 or newer
- Internet connection for installing packages
- Optional Gemini API key for AI-generated answers

## Run on Windows

1. Extract the ZIP file.
2. Open the extracted project folder.
3. Click the folder address bar, type `cmd`, and press Enter.
4. Run these commands one at a time:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

5. Open your browser and visit `http://127.0.0.1:5000`.

If `python` is not recognised, install Python from https://www.python.org/downloads/ and select **Add Python to PATH** during installation.

## Enable Gemini AI (optional)

1. Create an API key from Google AI Studio.
2. Set the `GEMINI_API_KEY` environment variable before starting the app.
3. Never publish your API key in GitHub or put it in this project’s source code.

Without a key, the app runs in demo mode and confirms the frontend/backend connection.

## Upload to GitHub

1. Create or open your GitHub repository.
2. Choose **Add file → Upload files**.
3. Extract the ZIP first, then drag the project files and folders into GitHub (do not upload the ZIP as the only project file unless your instructor specifically asks for a ZIP).
4. Enter a commit message such as `Add EduGenie learning assistant project`.
5. Click **Commit changes**.

## Note

This is a starter/demo project. Test it on your own computer and adapt the project details to your assignment requirements before submission.
